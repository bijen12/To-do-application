package com.example.todoapplication.todoapp.service;

public interface Authenticate {

	public boolean check(String name, String password);

}
